# ccopt saved state clock_trees.tcl.gz

create_ccopt_clock_tree -name clk -source CLK -no_skew_group 
