# ccopt saved state skew_groups.tcl.gz

## Tcl for skew_group
# Skew Group Mode: all
switch_ccopt_skew_group_mode -create all
# Skew Group: all
create_ccopt_skew_group -name all -generated  -auto_sinks -sources {{CLK rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: default
switch_ccopt_skew_group_mode -create default
# Skew Group: clk/sdc
create_ccopt_skew_group -name clk/sdc -from_clocks {clk} -from_constraint_modes {sdc} -from_delay_corners {de de} -auto_sinks -sources {CLK}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: fragment
switch_ccopt_skew_group_mode -create fragment
# Skew Group: 1
create_ccopt_skew_group -name 1 -generated  -fragment  -target_insertion_delay 0.150 -target_skew 0.023 -sinks {{cycleNum_reg[3]/CK} {cycleNum_reg[2]/CK} {cycleNum_reg[1]/CK} {cycleNum_reg[0]/CK} {PE9_trueOUT_reg[19]/CK} {PE9_trueOUT_reg[18]/CK} {PE9_trueOUT_reg[17]/CK} {PE9_trueOUT_reg[16]/CK} {PE9_trueOUT_reg[15]/CK} {PE9_trueOUT_reg[14]/CK} {PE9_trueOUT_reg[13]/CK} {PE9_trueOUT_reg[12]/CK} {PE9_trueOUT_reg[11]/CK} {PE9_trueOUT_reg[10]/CK} {PE9_trueOUT_reg[9]/CK} {PE9_trueOUT_reg[8]/CK} {PE9_trueOUT_reg[7]/CK} {PE9_trueOUT_reg[6]/CK} {PE9_trueOUT_reg[5]/CK} {PE9_trueOUT_reg[4]/CK} {PE9_trueOUT_reg[3]/CK} {PE9_trueOUT_reg[2]/CK} {PE9_trueOUT_reg[1]/CK} {PE9_trueOUT_reg[0]/CK} {PE8_trueOUT_reg[19]/CK} {PE8_trueOUT_reg[18]/CK} {PE8_trueOUT_reg[17]/CK} {PE8_trueOUT_reg[16]/CK} {PE8_trueOUT_reg[15]/CK} {PE8_trueOUT_reg[14]/CK} {PE8_trueOUT_reg[13]/CK} {PE8_trueOUT_reg[12]/CK} {PE8_trueOUT_reg[11]/CK} {PE8_trueOUT_reg[10]/CK} {PE8_trueOUT_reg[9]/CK} {PE8_trueOUT_reg[8]/CK} {PE8_trueOUT_reg[7]/CK} {PE8_trueOUT_reg[6]/CK} {PE8_trueOUT_reg[5]/CK} {PE8_trueOUT_reg[4]/CK} {PE8_trueOUT_reg[3]/CK} {PE8_trueOUT_reg[2]/CK} {PE8_trueOUT_reg[1]/CK} {PE8_trueOUT_reg[0]/CK} {PE7_trueOUT_reg[19]/CK} {PE7_trueOUT_reg[18]/CK} {PE7_trueOUT_reg[17]/CK} {PE7_trueOUT_reg[16]/CK} {PE7_trueOUT_reg[15]/CK} {PE7_trueOUT_reg[14]/CK} {PE7_trueOUT_reg[13]/CK} {PE7_trueOUT_reg[12]/CK} {PE7_trueOUT_reg[11]/CK} {PE7_trueOUT_reg[10]/CK} {PE7_trueOUT_reg[9]/CK} {PE7_trueOUT_reg[8]/CK} {PE7_trueOUT_reg[7]/CK} {PE7_trueOUT_reg[6]/CK} {PE7_trueOUT_reg[5]/CK} {PE7_trueOUT_reg[4]/CK} {PE7_trueOUT_reg[3]/CK} {PE7_trueOUT_reg[2]/CK} {PE7_trueOUT_reg[1]/CK} {PE7_trueOUT_reg[0]/CK} {PE6_trueOUT_reg[19]/CK} {PE6_trueOUT_reg[18]/CK} {PE6_trueOUT_reg[17]/CK} {PE6_trueOUT_reg[16]/CK} {PE6_trueOUT_reg[15]/CK} {PE6_trueOUT_reg[14]/CK} {PE6_trueOUT_reg[13]/CK} {PE6_trueOUT_reg[12]/CK} {PE6_trueOUT_reg[11]/CK} {PE6_trueOUT_reg[10]/CK} {PE6_trueOUT_reg[9]/CK} {PE6_trueOUT_reg[8]/CK} {PE6_trueOUT_reg[7]/CK} {PE6_trueOUT_reg[6]/CK} {PE6_trueOUT_reg[5]/CK} {PE6_trueOUT_reg[4]/CK} {PE6_trueOUT_reg[3]/CK} {PE6_trueOUT_reg[2]/CK} {PE6_trueOUT_reg[1]/CK} {PE6_trueOUT_reg[0]/CK} {PE5_trueOUT_reg[19]/CK} {PE5_trueOUT_reg[18]/CK} {PE5_trueOUT_reg[17]/CK} {PE5_trueOUT_reg[16]/CK} {PE5_trueOUT_reg[15]/CK} {PE5_trueOUT_reg[14]/CK} {PE5_trueOUT_reg[13]/CK} {PE5_trueOUT_reg[12]/CK} {PE5_trueOUT_reg[11]/CK} {PE5_trueOUT_reg[10]/CK} {PE5_trueOUT_reg[9]/CK} {PE5_trueOUT_reg[8]/CK} {PE5_trueOUT_reg[7]/CK} {PE5_trueOUT_reg[6]/CK} {PE5_trueOUT_reg[5]/CK} {PE5_trueOUT_reg[4]/CK} {PE5_trueOUT_reg[3]/CK} {PE5_trueOUT_reg[2]/CK} {PE5_trueOUT_reg[1]/CK} {PE5_trueOUT_reg[0]/CK} {PE4_trueOUT_reg[19]/CK} {PE4_trueOUT_reg[18]/CK} {PE4_trueOUT_reg[17]/CK} {PE4_trueOUT_reg[16]/CK} {PE4_trueOUT_reg[15]/CK} {PE4_trueOUT_reg[14]/CK} {PE4_trueOUT_reg[13]/CK} {PE4_trueOUT_reg[12]/CK} {PE4_trueOUT_reg[11]/CK} {PE4_trueOUT_reg[10]/CK} {PE4_trueOUT_reg[9]/CK} {PE4_trueOUT_reg[8]/CK} {PE4_trueOUT_reg[7]/CK} {PE4_trueOUT_reg[6]/CK} {PE4_trueOUT_reg[5]/CK} {PE4_trueOUT_reg[4]/CK} {PE4_trueOUT_reg[3]/CK} {PE4_trueOUT_reg[2]/CK} {PE4_trueOUT_reg[1]/CK} {PE4_trueOUT_reg[0]/CK} {PE3_trueOUT_reg[19]/CK} {PE3_trueOUT_reg[18]/CK} {PE3_trueOUT_reg[17]/CK} {PE3_trueOUT_reg[16]/CK} {PE3_trueOUT_reg[15]/CK} {PE3_trueOUT_reg[14]/CK} {PE3_trueOUT_reg[13]/CK} {PE3_trueOUT_reg[12]/CK} {PE3_trueOUT_reg[11]/CK} {PE3_trueOUT_reg[10]/CK} {PE3_trueOUT_reg[9]/CK} {PE3_trueOUT_reg[8]/CK} {PE3_trueOUT_reg[7]/CK} {PE3_trueOUT_reg[6]/CK} {PE3_trueOUT_reg[5]/CK} {PE3_trueOUT_reg[4]/CK} {PE3_trueOUT_reg[3]/CK} {PE3_trueOUT_reg[2]/CK} {PE3_trueOUT_reg[1]/CK} {PE3_trueOUT_reg[0]/CK} {PE2_trueOUT_reg[19]/CK} {PE2_trueOUT_reg[18]/CK} {PE2_trueOUT_reg[17]/CK} {PE2_trueOUT_reg[16]/CK} {PE2_trueOUT_reg[15]/CK} {PE2_trueOUT_reg[14]/CK} {PE2_trueOUT_reg[13]/CK} {PE2_trueOUT_reg[12]/CK} {PE2_trueOUT_reg[11]/CK} {PE2_trueOUT_reg[10]/CK} {PE2_trueOUT_reg[9]/CK} {PE2_trueOUT_reg[8]/CK} {PE2_trueOUT_reg[7]/CK} {PE2_trueOUT_reg[6]/CK} {PE2_trueOUT_reg[5]/CK} {PE2_trueOUT_reg[4]/CK} {PE2_trueOUT_reg[3]/CK} {PE2_trueOUT_reg[2]/CK} {PE2_trueOUT_reg[1]/CK} {PE2_trueOUT_reg[0]/CK} {PE1_trueOUT_reg[19]/CK} {PE1_trueOUT_reg[18]/CK} {PE1_trueOUT_reg[17]/CK} {PE1_trueOUT_reg[16]/CK} {PE1_trueOUT_reg[15]/CK} {PE1_trueOUT_reg[14]/CK} {PE1_trueOUT_reg[13]/CK} {PE1_trueOUT_reg[12]/CK} {PE1_trueOUT_reg[11]/CK} {PE1_trueOUT_reg[10]/CK} {PE1_trueOUT_reg[9]/CK} {PE1_trueOUT_reg[8]/CK} {PE1_trueOUT_reg[7]/CK} {PE1_trueOUT_reg[6]/CK} {PE1_trueOUT_reg[5]/CK} {PE1_trueOUT_reg[4]/CK} {PE1_trueOUT_reg[3]/CK} {PE1_trueOUT_reg[2]/CK} {PE1_trueOUT_reg[1]/CK} {PE1_trueOUT_reg[0]/CK} {PE2_WEIGHT_out_reg[1]/CK} {PE1_WEIGHT_out_reg[1]/CK} {PE2_WEIGHT_out_reg[2]/CK} {PE2_WEIGHT_out_reg[3]/CK} {PE1_WEIGHT_out_reg[2]/CK} {PE2_WEIGHT_out_reg[4]/CK} {PE1_INPUT_out_reg[1]/CK} {PE2_WEIGHT_out_reg[5]/CK} {PE1_WEIGHT_out_reg[3]/CK} {PE2_WEIGHT_out_reg[6]/CK} {PE1_INPUT_out_reg[5]/CK} {PE2_WEIGHT_out_reg[7]/CK} {PE1_WEIGHT_out_reg[4]/CK} {PE4_INPUT_out_reg[0]/CK} {PE1_INPUT_out_reg[2]/CK} {PE4_INPUT_out_reg[1]/CK} {PE4_INPUT_out_reg[2]/CK} {PE4_INPUT_out_reg[3]/CK} {PE4_INPUT_out_reg[4]/CK} {PE7_INPUT_out_reg[0]/CK} {PE1_WEIGHT_out_reg[5]/CK} {PE4_INPUT_out_reg[5]/CK} {PE4_INPUT_out_reg[6]/CK} {PE1_INPUT_out_reg[3]/CK} {PE4_INPUT_out_reg[7]/CK} {PE7_INPUT_out_reg[7]/CK} {PE3_WEIGHT_out_reg[0]/CK} {PE1_WEIGHT_out_reg[6]/CK} {PE3_WEIGHT_out_reg[1]/CK} {PE7_INPUT_out_reg[6]/CK} {PE7_INPUT_out_reg[5]/CK} {PE7_INPUT_out_reg[4]/CK} {PE7_INPUT_out_reg[3]/CK} {PE7_INPUT_out_reg[2]/CK} {PE7_INPUT_out_reg[1]/CK} {PE1_INPUT_out_reg[6]/CK} {PE3_WEIGHT_out_reg[2]/CK} {PE3_WEIGHT_out_reg[3]/CK} {PE1_WEIGHT_out_reg[7]/CK} {PE3_WEIGHT_out_reg[4]/CK} {PE1_INPUT_out_reg[7]/CK} {PE3_WEIGHT_out_reg[5]/CK} {PE1_INPUT_out_reg[0]/CK} {PE3_WEIGHT_out_reg[6]/CK} {PE3_WEIGHT_out_reg[7]/CK} {PE1_WEIGHT_out_reg[0]/CK} {PE2_WEIGHT_out_reg[0]/CK} {PE1_INPUT_out_reg[4]/CK} {PE5_INPUT_out_reg[1]/CK} {PE5_INPUT_out_reg[2]/CK} {PE5_INPUT_out_reg[3]/CK} {PE5_INPUT_out_reg[4]/CK} {PE5_INPUT_out_reg[5]/CK} {PE5_INPUT_out_reg[6]/CK} {PE5_INPUT_out_reg[7]/CK} {PE4_WEIGHT_out_reg[0]/CK} {PE4_WEIGHT_out_reg[1]/CK} {PE4_WEIGHT_out_reg[2]/CK} {PE4_WEIGHT_out_reg[3]/CK} {PE4_WEIGHT_out_reg[4]/CK} {PE4_WEIGHT_out_reg[5]/CK} {PE8_INPUT_out_reg[0]/CK} {PE4_WEIGHT_out_reg[6]/CK} {PE4_WEIGHT_out_reg[7]/CK} {PE2_INPUT_out_reg[0]/CK} {PE8_INPUT_out_reg[1]/CK} {PE8_INPUT_out_reg[2]/CK} {PE8_INPUT_out_reg[3]/CK} {PE8_INPUT_out_reg[4]/CK} {PE2_INPUT_out_reg[1]/CK} {PE8_INPUT_out_reg[5]/CK} {PE8_INPUT_out_reg[6]/CK} {PE8_INPUT_out_reg[7]/CK} {PE2_INPUT_out_reg[2]/CK} {PE6_WEIGHT_out_reg[0]/CK} {PE2_INPUT_out_reg[3]/CK} {PE2_INPUT_out_reg[4]/CK} {PE6_WEIGHT_out_reg[1]/CK} {PE6_WEIGHT_out_reg[2]/CK} {PE6_WEIGHT_out_reg[3]/CK} {PE6_WEIGHT_out_reg[4]/CK} {PE6_WEIGHT_out_reg[5]/CK} {PE6_WEIGHT_out_reg[6]/CK} {PE6_WEIGHT_out_reg[7]/CK} {PE5_WEIGHT_out_reg[0]/CK} {PE5_WEIGHT_out_reg[1]/CK} {PE5_WEIGHT_out_reg[2]/CK} {PE5_WEIGHT_out_reg[3]/CK} {PE5_WEIGHT_out_reg[4]/CK} {PE5_WEIGHT_out_reg[5]/CK} {PE5_WEIGHT_out_reg[6]/CK} {PE5_WEIGHT_out_reg[7]/CK} {PE5_INPUT_out_reg[0]/CK} {PE2_INPUT_out_reg[5]/CK} {PE2_INPUT_out_reg[6]/CK} {PE2_INPUT_out_reg[7]/CK}} -rank 0 -sources {{CLK rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: fragment_wns
switch_ccopt_skew_group_mode -create fragment_wns
# Skew Group Mode: icts
switch_ccopt_skew_group_mode -create icts
# Skew Group: clk/sdc
create_ccopt_skew_group -name clk/sdc -auto_sinks -sources {CLK}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: stagedepth
switch_ccopt_skew_group_mode -create stagedepth
# Skew Group: stagedepth
create_ccopt_skew_group -name stagedepth -generated  -auto_sinks -sources {{CLK rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group

# Switch back to default mode.
switch_ccopt_skew_group_mode default